package oppgave2;

public class oppgave2 {
    public static void main(String[] args){
        TallSpill tallspill = new TallSpill();
        tallspill.kjørSpill();
    }
}
