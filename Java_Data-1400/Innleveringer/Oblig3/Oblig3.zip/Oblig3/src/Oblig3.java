public class Oblig3{
    public static void main(String[] args) {
        UnikeTall unikeTall = new UnikeTall(50);

        /* Liste over studenter som leverer inn oppgavene
            Danils Trofimovs s374922
            Hashim Ul Hassan s353670
            Mert Tunahan Altunbas s376867
         */
    }
}
